def basic_salary(hourly_rate, hours_per_week):
    if hours_per_week > 40:
        regular_hours = 40
    else:
        regular_hours = hours_per_week
    weekly_salary = regular_hours * hourly_rate
    monthly_salary = weekly_salary * 4
    return monthly_salary


def overtime_salary(hourly_rate, hours_per_week):
    if hours_per_week > 40:
        overtime_hours = hours_per_week - 40
        overtime_rate = hourly_rate * 1.5
        weekly_overtime_pay = overtime_hours * overtime_rate
        monthly_overtime_pay = weekly_overtime_pay * 4
        return monthly_overtime_pay
    else:
        return 0


def total_salary(hourly_rate, hours_per_week):
    base_salary = basic_salary(hourly_rate, hours_per_week)
    overtime_pay = overtime_salary(hourly_rate, hours_per_week)
    return base_salary + overtime_pay


def tax_amount(basic_salary):
    if basic_salary < 60000:
        tax = basic_salary * 0.10
    elif 60000 <= basic_salary <= 85000:
        tax = basic_salary * 0.15
    else:
        tax = basic_salary * 0.20
    return tax


def gross_salary(basic_salary):
    allowances = basic_salary * 0.20
    tax_deducted = tax_amount(basic_salary)
    gross_sal = basic_salary + allowances - tax_deducted
    return gross_sal


def salary_bracket(gross_salary):
    if gross_salary < 50000:
        return "Low income"
    elif 50000 <= gross_salary <= 80000:
        return "Middle income"
    else:
        return "High income"


def employee_report():
    employees = []
    for i in range(3):
        print(f"\nEnter details for Employee {i+1}:")
        name = input("Name: ")
        hourly_rate = float(input("Hourly Rate: "))
        hours_per_week = int(input("Hours Worked per Week: "))

        basic_sal = basic_salary(hourly_rate, hours_per_week)
        gross_sal = gross_salary(basic_sal)
        tax_deducted = tax_amount(basic_sal)
        income_bracket = salary_bracket(gross_sal)

        employee_data = {
            "name": name,
            "basic_salary": basic_sal,
            "gross_salary": gross_sal,
            "tax": tax_deducted,
            "salary_bracket": income_bracket
        }

        employees.append(employee_data)
        print(f"\nDetails for Employee {i+1} collected. ")

    print("\nEmployee Salary Report")
    print("-"*50)
    print(f"{'Name':<15} {'Basic Salary':<15} {'Gross Salary':<15} {'Tax':<10} {'Bracket':<15}")
    print("-"*50)
    for emp in employees:
        print(f"{emp['name']:<15} {emp['basic_salary']:<15.2f} {emp['gross_salary']:<15.2f} {emp['tax']:<10.2f} {emp['salary_bracket']:<15}")
    print("-"*50)


employee_report()
