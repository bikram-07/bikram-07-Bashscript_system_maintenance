-- creating a sample database of a collage 
create database college;
use college;

create table student(
rollno int primary key,
name varchar(50),
marks int not null,
grade varchar(1),
city varchar(20)
);

create table dept(
id int primary key,
name varchar(50)
);
insert into dept
values
(101,"english"),
(102,"it");
select * from dept;


create table teacher(
id int primary key,
name varchar(50),
dept_id int,
foreign key(dept_id) references dept(id)
on update cascade
on delete cascade
);
insert into teacher 
values
(101,"adam",101),
(102,"eva",102);
select * from teacher;

update dept
set id=103
where id=102


insert into student
(rollno,name,marks,grade,city)
values
(101, "anil", 78, "C", "Pune"),
(102, "bhumika", 93, "A", "Mumbai"),
(103, "chetan", 85, "B", "Mumbai"),
(104, "dhruv", 96, "A", "Delhi"),
(105, "emanuel", 12, "F", "Delhi"),
(106, "farah", 82, "B", "Delhi");
select * from student;
-- selects the speficiec coluss from the database table.
select name,marks from student;
-- only show the distinct values of the city
select distinct city from student;

select * from student where marks>80;
select * from student where city="pune";

select * from student where marks>80 and city="mumbai";
-- studing the operators in the sql for the mering of the the different clauses conditions
select * from student where marks+10>100;


-- print in the asc order and also the top 3 will be printed here only
select * from student order by marks asc limit 3;

-- using of the aggregate functions here
select max(marks)from student;

select avg(mark )from student;

select count(name) from student;
-- using of the group by
select city ,count(rollno) from student city;
--  using of the group by here
select city ,name,count(rollno) from student group by name,city;

-- these gives us the marks average of each city
select city,avg(marks) from student group by city ;


-- solving the practise question now
-- write the query to find the avg marks in each city in ascendig order.
select city, avg(marks)  from student group by city order by avg(marks) asc ;

-- now here need to like sort by the grade now here
-- count the number of student whose marks cross like 90 
select city,count(rollno)
from student
 group by city
 having max(marks)>90;

 -- reacing a hard level is when you will be able to combine these concpest and use them to write out any query here out
SELECT city
FROM student
WHERE grade = "A"
GROUP BY city
HAVING MAX(marks) >=93
ORDER BY city asc;

-- table related queiry 

set sql_safe_updates =0;
update student
set grade="b"
where marks between 80 and 90;


-- deleteint the data from sql do carefully

delete from student
where marks<33;
select * from student;

-- here we will learn how to like add a coloumn in the table

alter table student
add column age int;
select * from student;
-- code to like drop the coloumn
alter table student
drop column age;

-- running some importnat queries here

-- setting the values to 19 deafalut if the age is not null
alter table student
add column age int not null default 19;
select * from student;


-- modifing the datatype 

alter table student
modify column age varchar(2);

-- after 6 we got these 
-- truncate data base 

truncate table student;
select * from student;

insert into student
(rollno,name,marks,grade,city)
values
(101, "anil", 78, "C", "Pune"),
(102, "bhumika", 93, "A", "Mumbai"),
(103, "chetan", 85, "B", "Mumbai"),
(104, "dhruv", 96, "A", "Delhi"),
(105, "emanuel", 12, "F", "Delhi"),
(106, "farah", 82, "B", "Delhi");

-- practise questions now question 1

-- Qs: In the student table :
-- a. Change the name of column" name to "full_ name".

alter table student 
change name full_name varchar(50);

-- b. Delete all the students who scored marks less than 80.

delete from student
where marks<80;
select * from student;

-- c. Delete the column for grades.
alter table student
drop column grade;
select * from student;


-- practising the natualy joing

select * from student;
select * from course;


-- pracstising the subquery here now
select * from student;
truncate table student;


create table student(
rollno int primary key,
name varchar(50),
marks int not null,
grade varchar(1),
city varchar(20)
);

insert into student
(rollno,name,marks,grade,city)
values
(101, "anil", 78, "C", "Pune"),
(102, "bhumika", 93, "A", "Mumbai"),
(103, "chetan", 85, "B", "Mumbai"),
(104, "dhruv", 96, "A", "Delhi"),
(105, "emanuel", 12, "F", "Delhi"),
(106, "farah", 82, "B", "Delhi");

-- Get names of all students who scored more than class average.
-- Step 1. Find the avg of class
-- Step 2. Find the names of students with marks > avg

select avg(marks)
from student;

select name ,marks
from student 
where marks>76;

-- dynimically doint these now

select name, marks
from student
where marks > (select avg(marks)from student);



-- Example
-- Find the names of all students with even roll numbers.
-- Step 1. Find the even roll numbers
-- Step 2. Find the names of students with even roll no


select * from student;

select rollno
from student
where rollno%2=0;

select name,rollno 
from student
where rollno in (select rollno
from student
where rollno%2=0);


-- SQL Sub Queries
-- Example with FROM
-- Find the max marks from the students of Delhi
-- Step 1. Find the students of Delhi
-- Step 2. Find their max marks using the sublist in step 1

select max(marks)
from (select * from student where city="delhi") as temp;

-- using the view feature here
create view view1 as
select rollno,name,marks from student;
select * from view1;
drop view view1;


-- 



